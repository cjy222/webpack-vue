<template>
  <div :class="$style['oneDiv']">123<span :class="$style['a']">4</span></div>
</template>
<style module>
  @import "./a.css";
  .oneDiv {
    font-size: 20px;
    color: turquoise;
  }
</style>